#include<iostream>
using namespace std;
class abc{
    public :
    int multiplication(int,int);
};
inline int abc ::multiplication(int a,int b){
    return a * b;
}
int main (){
    abc a1;
    int i,num;
    cout<<"Enter table number :";
    cin>>num;
    for(i=1;i<=10;i++){
        cout<<num<<"*"<<i<<"="<<a1.multiplication(i,num)<<endl;
    }
        
    return 0;
}