#include<iostream>
using namespace std;
class abc {
    public :
        inline int add(int,int);
        inline int sub(int,int);
        inline int multiply(int,int);
        inline int division(int,int);
        inline int modulas(int,int);
};

inline int abc :: add(int a,int b){
    return a + b ;
} 


inline int abc :: sub(int a,int b){
    return a - b ;
} 


inline int abc :: multiply(int a,int b){
    return a * b ;
} 



inline int abc :: division(int a,int b){
    return a / b ;
} 


inline int abc :: modulas(int a,int b){
    return a % b ;
} 
int main (){
    abc a1;
    int p,q;
    cout<<"Enter p & q : "<<endl;
    cin>>p>>q;
    cout<<"addition is "<<a1.add(p,q)<<endl;
    cout<<"substraction is "<<a1.sub(p,q)<<endl;
    cout<<"multiplication is "<<a1.multiply(p,q)<<endl;
    cout<<"division is "<<a1.division(p,q)<<endl;
    cout<<"modulas is "<<a1.modulas(p,q)<<endl;

}