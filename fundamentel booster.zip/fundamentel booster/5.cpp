
#include<iostream>
#include<cmath>
using namespace std;

int main(){
// WAP to find square root of given numbers from array elements.
    int i,size,arr[50];
    cout<<"Enter the size of array : "<<endl;
    cin>>size;
    cout<<"Enter the element want to square root of number : "<<endl;
    
    for(i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Square root answer is : "<<endl;

    for(i=0;i<size;i++)
    {
        cout<<sqrt(arr[i])<<endl;
    }
}