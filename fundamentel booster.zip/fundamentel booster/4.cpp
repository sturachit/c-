#include<iostream>
using namespace std;
//4. WAP to check if a given character is vowel or consonant.
int main(){
    char vowel;
    cout<<"Enter any alphabet"<<endl;
    cin>>vowel;

    if(vowel == 'a' || vowel == 'A' || vowel == 'e' || vowel == 'E' || vowel == 'i' || vowel == 'I' || vowel == 'o' || vowel == 'O' || vowel == 'u' || vowel == 'U')
    {
        cout<<vowel<<" is vowel.";
    }
    else
    {
        cout<<vowel<<" is consonant.";
    }
}