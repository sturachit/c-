#include<iostream>
using namespace std;
// WAP to find leap years from 2000 to 3000.

int main(){
    int i;
    for(i=2000;i<=3000;i++)
    {
        if(i % 4 == 0)
        {
            cout << i << endl;
        }
    }
}