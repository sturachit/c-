
#include<iostream>
using namespace std;

int main(){
// WAP to generate cube of given 5 numbers and make an array of that generated cubes.
    int i,size,arr[50];
    cout<<"Enter the size of array : "<<endl;
    cin>>size;
    cout<<"Enter the element of array : "<<endl;
    
    for(i=0;i<size;i++)
    {
        cin >> arr[i];
    }

    cout<<"Cube element is : "<<endl;

    for(i=0;i<size;i++)
    {
        cout << arr[i] * arr[i] * arr[i] << endl;
    }
}