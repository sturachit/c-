#include <iostream>
using namespace std;
int main()
{
// 1. WAP to check given string is numeric or not.
    char name[50];
    int i,r = 0;
    cout << "Enter Name is : ";
    cin >> name;

    for (i = 0; name[i] != '\0'; i++)
    {
        if (name[i] >= '0' && name[i]<= '9')
        {
            r = 1;
        }
    }
    if (r == 0)
    {
        cout << "String is alphabetic";
    }
    else
    {
        cout << "String is numeric";
    }
}