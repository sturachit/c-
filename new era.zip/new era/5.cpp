#include<iostream>
using namespace std;
class student{
    //5. WAP which illustrates the use of public and private access modifiers.
private:
  int a,b;
public:
    void getdata (int p,int q){
            this->a =p;
            this->b =q;
    }
    void putdata();
};

void student::putdata(){
    cout<<"Addition is"<<a + b<<endl;
}
int main() {
    student s1;
    s1.getdata(20,10);
    s1.putdata();
    return 0;
}