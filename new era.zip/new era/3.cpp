#include <iostream>
using namespace std;

class Time {
    private:
        int hours;
        int minutes;
        int seconds;
    public:
        void getTime() {
            cout << "Enter time in seconds: ";
            cin >> seconds;
        }
        void convertTime() {
            minutes = seconds / 60;
            hours = minutes / 60;
            minutes = minutes % 60;
            seconds = seconds % 60;
        }
        void displayTime() {
            cout << "Time is : " << hours << ":" << minutes << ":" << seconds << endl;
        }
};



int main() {
    Time t;
    t.getTime();
    t.convertTime();
    t.displayTime();
    return 0;
}
