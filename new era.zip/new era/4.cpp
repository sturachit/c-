#include <iostream>
using namespace std;
class house
{
    //4. WAP to create a class which Read and Print House details along with Room details.
public:
    int house_number;
    int house_rent;
    int house_rooms;
    char house_name[50];
};

int main(){
    house h1;
    cout<<"Enter the house number: ";
    cin>>h1.house_number;
    cout<<"Enter the house rent: ";
    cin>>h1.house_rent;
    cout<<"Enter the house rooms: ";
    cin>>h1.house_rooms;
    cout<<"Enter the house name: ";
    cin>>h1.house_name;
    cout<<"House number is : "<<h1.house_number<<endl;
    cout<<"House rent is :"<<h1.house_rent<<endl;
    cout<<"House Room is :"<<h1.house_rooms<<endl;
    cout<<"House name is :"<<h1.house_name<<endl;
    return 0;
}