#include <iostream>
using namespace std;

class Time {
    private:
        int hours;
        int minutes;
    public:
        void getTime() {
            cout << "Enter time:" << endl;
            cout << "Hours: ";
            cin >> hours;
            cout << "Minutes: ";
            cin >> minutes;
        }
        void displayTime() {
            cout << "Time: " << hours << " hours and " << minutes << " minutes." << endl;
        }
        Time addTime(Time t2) {
            Time t;
            t.minutes = minutes + t2.minutes;
            t.hours = hours + t2.hours + (t.minutes / 60);
            t.minutes = t.minutes % 60;
            return t;
        }
};

int main() {
    Time t1, t2, t3;
    t1.getTime();
    t2.getTime();
    t3 = t1.addTime(t2);
    t3.displayTime();
    return 0;
}
