#include<iostream>
using namespace std;
    //hierirchical inheritence
class A{
    protected :
    int a,b;
    void add(){
        cout<<"Enter a & b :"<<endl;
        cin>>a>>b;
    }

    void printData(){
    cout<<"Addition is  :"<<a + b<<endl;
    }
};

class B : protected A{
    public : 
        void setData(){
            add();
            printData();
        }
};

class C : private A{
    public : 
    void mult(){
        cout<<"Enter a & b :"<<endl;
        cin>>a>>b;
        cout<<"MUltiplication is :"<<a * b<<endl;
    }
};

int main(){
    B obj;
    C obj;
    obj.setData();
    obj.mult();
    return 0;
}