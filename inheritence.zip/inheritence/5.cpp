#include<iostream>
using namespace std;
class A{
    public :
    virtual void disp(){
        cout<<"class A called"<<endl; 
    }
};

class B : virtual public A{
    public : 
    void disp(){
        cout<<"class B called"<<endl;
    }
};

class C : virtual public A{
    public : 
    void disp(){
        cout<<"class C called"<<endl;
    }
};

class D : virtual public C{
    public : 
    void disp(){
        cout<<"class D called"<<endl;
    }
};

int main(){
    D objD;
    B obj;
    obj.B :: disp();
    objD.A :: disp();
    objD.C :: disp();
    objD.disp();
    return 0;
}