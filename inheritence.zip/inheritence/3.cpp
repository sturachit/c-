#include<iostream>
using namespace std;
    //multiple inheritence
class abc{
    int a,b;
    public :
    void getData(int A,int B){
        this->a = A;
        this->b=B;
        }
        void setData(){
            cout<<"MUltiplication is "<<a*b<<endl;
        }
};

class xyz : public abc{
    int r;
    public : 
       int cube(int p){
        this->r = p;
        return r*r*r;
       }
};


class pqr : public xyz{
    int z;
    public : 
    pqr(int p){
        this->z = p;
    }
    int square(){
        return z*z;
    }
};
int main(){
    pqr x1(10);
    cout<<"Sqaure is "<<x1.square()<<endl;
    cout<<"cube is "<<x1.cube(10)<<endl;
    x1.getData(5,12);
    x1.setData();
    return 0;
}