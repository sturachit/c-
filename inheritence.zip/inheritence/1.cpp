#include<iostream>
using namespace std;
    //single inheritence
class abc{
    public :
    void getData(){
        cout<<"Base class"<<endl;
    }
};

class xyz : public abc{
    public : 
        void putData(){
            cout<<"derived class"<<endl;
        }
};
int main(){
    xyz a1;
    a1.getData();
    a1.putData();
    return 0;
}