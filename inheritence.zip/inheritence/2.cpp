#include<iostream>
using namespace std;
    //multilevel inheritence
class abc{
    public :
    void getData(){
        cout<<"Base class"<<endl;
    }
};

class xyz : public abc{
    public : 
        void putData(){
            cout<<"derived class"<<endl;
        }
};

class pqr : public xyz{
    public : 
    void setData(){
        cout<<"pqr - derived class"<<endl;
    }
};

int main(){
    pqr a1;
    a1.getData();
    a1.putData();
    a1.setData();
    return 0;
}