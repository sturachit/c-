#include <iostream>
#include <string>
using namespace std;

class Animal
{

protected:
  string name;

  int age;

public:
  void set_value(int a, string n)
  {

    age = a;

    name = n;
  }
};

class Zebra : public Animal
{

public:
  void displayZebraMessage()
  {

    cout << "The zebra name is " << name << ". The zebra is " << age << " years old \n";
  }
};

class Dolphin : public Animal
{

public:
  void displayDolphinMessage()
  {

    cout << "The dolphin name is: " << name << ". The dolphin is " << age << "years old\n";
  }
};

int main()
{

  Zebra z;

  Dolphin d;

  string r1 = "han";

  string r2 = "bella";

  z.set_value(10, r1);

  d.set_value(5, r2);

  z.displayZebraMessage();

  d.displayDolphinMessage();

  return 0;
}
