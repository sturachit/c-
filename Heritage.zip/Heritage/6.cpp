#include <iostream>
using namespace std;

class A
{
public:
    int id;
    char name[100];
    char role[100];
    int salary;
    int experience;
    char comp_name[100];
    char address[100];
    char email[100];
    int contact;

    void getAinfo()
    {
        cout << "Enter ID :- " << endl;
        cin >> id;
        cout << "Enter Name :- " << endl;
        cin >> name;
        cout << "Enter Role :- " << endl;
        cin >> role;
    }
};
class B : public A
{
public:
    void getBinfo()
    {
        cout << "Enter Salary :-" << endl;
        cin >> salary;
        cout << "Enter Experience :-" << endl;
        cin >> experience;
    }
};
class C : public B
{
public:
    void getCinfo()
    {
        cout << "Enter compey Name :-" << endl;
        cin >> comp_name;
        cout << "Enter Address :-" << endl;
        cin >> address;
    }
    void getABinfo()
    {
        cout << name << endl;
        cout << role << endl;
        cout << salary << endl;
    }
};
class D : public C
{
public:
    void getDinfo()
    {
        cout << "Enter Email :-" << endl;
        cin >> email;
        cout << "Enter Contact :-" << endl;
        cin >> contact;
    }
    void getAllinfo()
    {
        cout << "------------- Employee Information -----------------";
        cout << "\tEmployee ID - " << id << endl;
        cout << "\tEmployee Name - " << name << endl;
        cout << "\tEmployee Role - " << role << endl;
        cout << "\tEmployee Salary - " << salary << endl;
        cout << "\tEmployee Experience - " << experience << endl;
        cout << "\tEmployee compey Name - " << comp_name << endl;
        cout << "\tEmployee Address - " << address << endl;
        cout << "\tEmployee Email - " << email << endl;
        cout << "\tEmployee Contact - " << contact << endl;
        cout << "---------------- Thank You --------------------";
    }
};

int main()
{
    D r1;
    r1.getAinfo();
    r1.getBinfo();
    r1.getCinfo();
    r1.getABinfo();
    r1.getDinfo();
    r1.getAllinfo();
}
