#include <iostream>
using namespace std;

class Mother
{

public:
    Mother(){};

    void disp()
    {
        cout << "Im the mother!" << endl;
    };
};

class Daughter : public Mother
{

public:
    Daughter(){};

    void disp()
    {
        cout << "Im the daugther!" << endl;
    };
};

int main()
{

    Mother M;
    Daughter D;
    M.disp();
    D.disp();

    return 0;
}
