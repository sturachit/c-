#include <iostream>
using namespace std;

class Number {
protected:
    int num;

public:
    void read_num() {
        cout << "Enter a number: ";
        cin >> num;
    }
};

class Square : public Number {
public:
    int get_square() {
        return num * num;
    }
};

class Cube : public Number {
public:
    int get_cube() {
        return num * num * num;
    }
};

int main() {
    Square s;
    s.read_num();
    cout << "Square: " << s.get_square() << endl;

    Cube c;
    c.read_num();
    cout << "Cube: " << c.get_cube() << endl;

    return 0;
}
