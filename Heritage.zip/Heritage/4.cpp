#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;

public:
    void read_person_info() {
        cout << "Enter name: ";
        getline(cin, name);
        cout << "Enter age: ";
        cin >> age;
    }

    void print_person_info() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

class Employee {
protected:
    int employee_id;
    double salary;

public:
    void read_employee_info() {
        cout << "Enter employee ID: ";
        cin >> employee_id;
        cout << "Enter salary: ";
        cin >> salary;
    }

    void print_employee_info() {
        cout << "Employee ID: " << employee_id << endl;
        cout << "Salary: " << salary << endl;
    }
};

class EmployeeInfo : public Person, public Employee {
public:
    void read_info() {
        read_person_info();
        read_employee_info();
    }

    void print_info() {
        print_person_info();
        print_employee_info();
    }
};

int main() {
    EmployeeInfo e;
    e.read_info();
    e.print_info();

    return 0;
}
