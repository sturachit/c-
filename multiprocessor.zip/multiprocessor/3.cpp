#include <iostream>
using namespace std;
//3. WAP which illustrate the use of Method Overriding concept.
class pqr
{
public:
    int cube(int);
};
class xyz : public pqr
{
public:
    int cube(int r)
    {
        return r * r * r;
    }
};

int main()
{
    xyz x1;
    int no;
    cout << "Enter no : ";
    cin >> no;
    cout << "Cube is : " << x1.cube(no);
}