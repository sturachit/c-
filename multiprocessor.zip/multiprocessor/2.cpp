#include <iostream>
using namespace std;
//2. WAP to create a class that contains four member functions, with 0, 1, 2, and 3 int arguments, respectively. Create a main( ) that makes an object of your class and calls each of the member functions. Now modify the class so it has instead a single member function with all the arguments defaulted.
class member
{

public:
  int a = 0;
  int b = 1;
  int c = 2;
  int d = 3;

public:
  void getdata()
  {

    cout << "Enter four numbers" << endl;
    cin >> a;
    cin >> b;
    cin >> c;
    cin >> d;
  };

  void putdata()
  {

    cout << "Display all numbers" << endl;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cout << d << endl;
  };
};

int main()
{

  member r;

  r.getdata();

  r.putdata();
}