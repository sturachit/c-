
#include <iostream>
using namespace std;
//5. WAP for unary increment (++) and decrement (--) operator overloading.
class xyz
{
    int a,b;

public:
    xyz()
    {
        cout << "Enter a ";
        cin >> a;
        cout << "Enter a ";
        cin >> b;
    }
    void operator++()
    {
        ++a;
    }
    void operator--()
    {
        --b;
    }
    void disp()
    {
        cout << "a is - " << a<<endl;
        cout << "b is - " << b;
    }
};

int main()
{
    xyz x1;
    ++x1;
    --x1;
    x1.disp();
}