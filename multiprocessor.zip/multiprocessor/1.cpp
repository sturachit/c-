#include <iostream>
using namespace std;
// 1. WAP to create a Message class with a constructor that takes a single string with a default value. Create a private member string, and in the constructor simply assign the argument string to your internal string. Create two overloaded member functions called print( ): one that takes no arguments and simply prints the message stored in the object, and one that takes a string argument, which it prints in addition to the internal message.
class Message
{
    string r1;  
    string r2;

public:
    Message(string r3)
    {
        this->r1 = r3;
    }

    void printf()
    {
        cout << "no argument " << endl;
    }

    void display(string r5)
    {
        this->r2 = r5;
        cout << r1 + r2;
    }
};

int main()
{
    Message r("Hi - ");

    r.printf();
    r.display("rachit..");
    return 0;
}