#include <iostream>
using namespace std;
//4. WAP to demonstrate usage of Virtual Function & pure virtual function.  
class A
{
public:
    virtual void disp()
    {
        cout << "class A " << endl;
    }
};

class B : virtual public A
{
public:
    void disp()
    {
        cout << "class B " << endl;
    }
};

class C : virtual public A
{
public:
    void disp()
    {
        cout << "class c " << endl;
    }
};

class D : public B, public C
{
public:
    void disp()
    {
        cout << "class D " << endl;
    }
};

int main()
{

    D objD;
    objD.B::disp();
    objD.C::disp();
    objD.A::disp();
}

// ---------------------------------------pure virtual--------------------------------

// #include<iostream>
// using namespace std;

// class A{
//     public:
//     virtual void disp()=0;
// };

// class B: public A{
//     public:
//     void disp(){
//         cout<<"class B "<<endl;
//     }
// };

// class C:  public A{
//     public:
//     void disp(){
//         cout<<"class c "<<endl;
//     }
// };

// class D: public B, public C{
//     public:
//     void disp(){
//         cout<<"class D "<<endl;
//     }
// };

// int main(){

// D objD;
// objD.B::disp();
// objD.C::disp();
// objD.disp();

// }