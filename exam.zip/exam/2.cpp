#include <iostream>
using namespace std;
class Cricket
{
public:
    virtual int getTotalOvers()
    {
        return 50;
    }
};

class T20Match : public Cricket
{
public:
    int getTotalOvers()
    {
        return 20;
    }
};

class TestMatch : public Cricket
{
public:
    int getTotalOvers()
    {
        return 90;
    }
};
int main()
{
    Cricket *cric;
    T20Match t20;
    TestMatch test;

    cric = &t20;
    cout << "Total overs in T20 match: " << cric->getTotalOvers() << endl;
    cric = &test;
    cout << "Total overs in Test match: " << cric->getTotalOvers() << endl;

    return 0;
}
