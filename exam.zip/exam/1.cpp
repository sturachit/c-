
#include <iostream>
#include <cmath>
using namespace std;

class Shape
{
public:
    virtual double calculate() = 0;
};

class Triangle : public Shape
{
private:
    double base;
    double height;

public:
    Triangle(double b, double h) : base(b), height(h) {}
    double calculate()
    {
        return 0.5 * base * height;
    }
};

class Circle : public Shape
{
private:
    double radius;

public:
    Circle(double r) : radius(r) {}
    double calculate()
    {
        return M_PI * radius * radius;
    }
};

class Rectangle : public Shape
{
private:
    double length;
    double width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}
    double calculate()
    {
        return length * width;
    }
};

int main()
{

    Triangle t(4.0, 5.0);
    Circle c(3.0);
    Rectangle r(4.0, 5.0);

    cout << "Area of triangle: " << t.calculate() << endl;
    cout << "Area of circle: " << c.calculate() << endl;
    cout << "Area of rectangle: " << r.calculate() << endl;

    return 0;
}