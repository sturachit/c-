#include <iostream>
using namespace std;
class A
{
public:
    virtual void disp()
    {
        cout << "class A " << endl;
    }
};
class B : virtual public A
{
public:
    void disp()
    {
        cout << "class B " << endl;
    }
};
class C : virtual public A
{
public:
    void disp()
    {
        cout << "class c " << endl;
    }
};
class D : public B, public C
{
public:
    void disp()
    {
        cout << "class D " << endl;
    }
};
int main()
{
    D D1;
    D1.A::disp();
    D1.B::disp();
    D1.C::disp();
}