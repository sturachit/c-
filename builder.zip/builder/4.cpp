#include <iostream>
using namespace std;
        //4) WAP to create a class which Set values of data members using default, parameterized and copy constructor,destructor.

class data {

public:
    //Default constructor
    data() {
        cout << "Default constructor called" << endl;
    }
    //parameterized constructor
    data(int a,int b){
        cout<<"multiplication is "<<a*b<<endl;
    }

    //copy constructor
    void display(int x,int y){
        cout<<"x is "<<x<<endl;
        cout<<"y is "<<y<<endl;
    }

    //delete constructor
    ~data(){
        cout << "Destructor deleted" << endl;
    }

};


int main() {
    data s1;
    data s2(20,30);
    data s3=s1;
    s1.display(20,30);

    return 0;
}
