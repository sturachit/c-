#include<iostream>
using namespace std;
// 5. WAP to make Railway Reservation System.
class StoreData{
    private:
        int train_no;
        string train_name;
        string source;
        string destination;
        string time;
    public:
        void setdata(int a,string b,string c,string d,string e)
        {
            this->train_no=a;
            this->train_name=b;
            this->source=c;
            this->destination=d;
            this->time=e;
        }
        int getTrain_no()
        {
            return this->train_no;
        }
        string getTrain_name()
        {
            return this->train_name;
        }
        string getSource()
        {
            return this->source;
        }
        string getDestination()
        {
            return this-> destination;
        }
        string getTime()
        {
            return this->time;
        }
};
class Train{
    private:
        int train_no;
        string train_name;
        string source;
        string destination;
        string time;
    public:
    void setdata(int a,string b,string c,string d,string e)
    {
        this->train_no=a;
        this->train_name=b;
        this->source=c;
        this->destination=d;
        this->time=e;
    }
    int getTrain_no()
    {
        return this->train_no;
    }
    string getTrain_name()
    {
        return this->train_name;
    }
    string getSource()
    {
        return this->source;
    }
    string getDestination()
    {
        return this-> destination;
    }
    string getTime()
    {
        return this->time;
    }
};
int main(){
    int n,train_no,count=0,count1=0;
    string train_name;
    string source;
    string destination;
    string time;
    Train t1;
    StoreData s[3],s1;
    
    s[0].setdata(2156,"Super Delux Express","Delhi","Mumbai","16:00");
    s[1].setdata(1190,"Rajdhani Express","Rajkot","Chennai","20:30");
    s[2].setdata(5045,"India Express","Ahmedabad","Surat","2:45");
    
    cout<<"\n=====Train Details====== "<<endl;
    
    for(int i=0;i<3;i++)
    {
        cout<<"Train Number :"<<s[i].getTrain_no()<<endl;
        cout<<"Train Name :"<<s[i].getTrain_name()<<endl;
        cout<<"Train Number :"<<s[i].getTrain_no()<<endl;
        cout<<"Train From :"<<s[i].getSource()<<endl;
        cout<<"Train Destination :"<<s[i].getDestination()<<endl;
        cout<<"Train Time :"<<s[i].getTime()<<endl;
        cout<<"____________________";
    }
    
    cout<<endl<<endl<<" Enter Your Choice : 1) for Booking 2) for Search by Train Number 3) Exit to PressAny Key"<<endl;
    cin>>n;
    
    switch (n){
    case 1:
        cout<<"\nWelcome to Booking Department "<<endl;
        cout<<"\nEnter the Train Number : "<<endl;
        cin>>train_no;
        cout<<"\nEnter the Train_name : "<<endl;
        cin>> train_name;
        cout<<"\nFrom where : "<<endl;
        fflush(stdout);
        cin>> source;
        cout<<"\nwhere to : "<<endl;
        cin>> destination;
        cout<<"\nEnter the time : "<<endl;
        cin>> time;
        s1.setdata(train_no,train_name,source,destination,time);
        
        for(int i=0;i<3;i++)
        {
            if(train_no==s[i].getTrain_no() && train_name==s[i].getTrain_name() &&
            source==s[i].getSource() && destination==s[i].getDestination() && time==s[i].getTime() )
            {
                t1.setdata(train_no,train_name,source,destination,time);
                count=1;
            }
        }
        if(count==0)
        {
            cout<<"Invalid Reservation  ";
        }
        else
        {
            cout<<"Your booking is Confirm ";
        }
        break;
        
    case 2:
        cout<<"Enter the Train Number";
        cin>>train_no;
        
        for(int i=0;i<3;i++)
        {
            if(train_no==s[i].getTrain_no())
            {
                cout<<"\nTrain Number :"<<s[i].getTrain_no()<<endl;
                cout<<"\nTrain Name :"<<s[i].getTrain_name()<<endl;
                cout<<"\nTrain Number :"<<s[i].getTrain_no()<<endl;
                cout<<"\nTrain Source :"<<s[i].getSource()<<endl;
                cout<<"\nTrain Destination :"<<s[i].getDestination()<<endl;
                cout<<"\nTrain Time :"<<s[i].getTime()<<endl;
                count1=1;
            }
        }
        if(count1==0)
        {
            cout<<"Not Found ";
        }
        break;
        default:
        break;
        }
}

