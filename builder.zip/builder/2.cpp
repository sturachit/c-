#include<iostream>
#include<string.h>
using namespace std;
//2. WAP to create a class Hotel with fields like id, name, type, staff_size, room_size, establish_year, address, rating_type and website. Illustrate the use of encapsulation (strict encapsulation) with this keyword.
class hotel{
    private:
        int id;
        int staff_size;
         int establish_year;
        int rating_type;
        string hotel_name;
        string type;
        char room_size[100];
        char website[100];
        string address;
        
    public:
        void setData(){
        cout<<"-----Details of hotel----- "<<endl;
        cout<<"Enter hotel id : ";
        cin>>this->id;
        cout<<"\nEnter hotel name : ";
        cin>>this->hotel_name;
        cout<<"\nEnter hotel type : ";
        cin>>this->type;
        cout<<"\nEnter hotel staff size : ";
        cin>>this->staff_size;
        cout<<"\nEnter hotel room size : ";
        cin>>this->room_size;
        cout<<"\nEnter hotel establish year : ";
        cin>>this->establish_year;
        cout<<"\nEnter hotel address : ";
        cin>>this->address;
        cout<<"\nEnter hotel rating type : ";
        cin>>this->rating_type;
        cout<<"\nEnter hotel website : ";
        cin>>this->website;
    }

    void getData(){
        cout<<"-----Hotel details-----  "<<endl;

        cout<<"Hotel id : "<<id<<endl;
        cout<<"Hotel name : "<<hotel_name<<endl;
        cout<<"Hotel type : "<<type<<endl;
        cout<<"Hotel staff size : "<<staff_size<<endl;
        cout<<"Hotel room size : "<<room_size<<endl;
        cout<<"Hotel establish year : "<<establish_year<<endl;
        cout<<"Hotel address : "<<address<<endl;
        cout<<"Hotel rating type : "<<rating_type<<endl;
        cout<<"Hotel website : "<<website<<endl;
    }
};

int main(){
    hotel h1;
    h1.setData();
    h1.getData();
}