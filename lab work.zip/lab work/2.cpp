#include<iostream>
using namespace std;
        //2. WAP to convert given degree celsius temperature into fahrenheit and convert that fahrenheit temperature into kelvin by   implementing multilevel inheritance: Class P -> Class Q -> Class R
class temp{
    public:
        float celsius,fahrenheit,kelvin;
};

class TEMP : public temp{
    public:
        void toFahrenheit(){
            cout<<"Enter tempreture in celsius is : ";
            cin>>celsius;
            fahrenheit = (celsius * 9.0) / 5.0 + 32;
            cout<<"The tempreture in  fahrenheit is : "<<fahrenheit<<endl;
        }
};

class temprature : public TEMP{
        public:
            void toKelvin(){
                kelvin = 273.5 + ((fahrenheit - 32.0) * (5.0/9.0));
                cout<<"The tempreture in kelvin is : "<<kelvin<<endl;
            }
};

int main(){
    temprature t1;
    t1.toFahrenheit();
    t1.toKelvin();
    return 0;
}