#include<iostream>
using namespace std;
    //1. WAP to find sum of all three number’s cubes by implementing single level inheritance: Class X->Class Y
class X{
    public:
        int p,q,r;
        int a,b,c;
        int sum=0;
};

class Y : public X{
    public:
        void getData(){
            cout<<"Enter value of p : "<<endl;
            cin>>p;
            cout<<"Enter value of q : "<<endl;
            cin>>q;
            cout<<"Enter value of r : "<<endl;
            cin>>r;
        }
        void cube(){
            a=p*p*p;
            b=q*q*q;
            c=r*r*r;
            sum=a+b+c;
        }
        void setdata(){
            cout<<"cube a is : "<<a<<endl;
            cout<<"cube b is : "<<b<<endl;
            cout<<"cube c is : "<<c<<endl;
            cout<<"Sum of all three cube is : "<<sum<<endl;
        }
};

int main(){
    Y y1;
    y1.getData();
    y1.cube();
    y1.setdata();
    return 0;
}